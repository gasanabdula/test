US-Only eBay Titles Quick Restore
---------------------------------
Files:
- make_titles.py        (US Cassini-optimized generator)
- verify_titles.py      (checks ≤80 chars, ≤2 pipes, no trailing seps)
- run_titles.bat        (one-click runner with delete prompts)
- input.csv             (sample header format)
- openai_keys.txt       (put your OpenAI key on FIRST line)
- utils.py              (shared cleaners: pipes, inches, dimensions, restricted words)

How to run:
1) Extract to D:\ebay_titles
2) Put your API key in openai_keys.txt (first line only).
3) Prepare D:\ebay_titles\input.csv with header:
   ASIN,amazon_title,amazon_description,bullet_points
4) Double-click run_titles.bat
   → Outputs: yaballe_titles.txt + titles_log.txt (ASIN;TITLE)

If you see an OpenAI import error:
   pip install --upgrade openai
