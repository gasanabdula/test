# make_titles.py — US Cassini-optimized title generator with guards, hard cap, and multi-key failover
import os, csv, random, time, re, sys
from typing import List, Dict
from utils import clean_title, smart_trim, strip_trailing_seps

INPUT_FILE = os.environ.get("INPUT_FILE", "input.csv")
OUTPUT_FILE = os.environ.get("OUTPUT_FILE", "yaballe_titles.txt")
LOG_FILE = os.environ.get("LOG_FILE", "titles_log.txt")
KEY_FILE = os.environ.get("OPENAI_KEY_FILE", "openai_keys.txt")
MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
MAX_LEN = int(os.environ.get("MAX_TITLE_LEN", "80"))
RPM = int(os.environ.get("RPM", "120"))  # requests per minute soft target

# Rotate keys on these conditions
SWITCH_ON_RATE_LIMIT = True
SWITCH_ON_INVALID_KEY = True

RISKY = {
    "laptop","notebook","macbook","chromebook","computer","pc","desktop","monitor","screen",
    "tv","television","oled","qled","4k","gaming pc","gpu","nvidia","geforce","rtx","intel","amd","ryzen","core i3","core i5","core i7",
    "iphone","android","samsung","pixel","tablet","ipad","kindle"
}

def _sleep_rate():
    if RPM > 0:
        time.sleep(60.0 / RPM)

def _prompt(asn: str, title: str, desc: str, bullets: str) -> str:
    big = " ".join(x for x in [title, desc, bullets] if x).strip()
    big = re.sub(r"\s+", " ", big)
    user = f"ASIN: {asn}\nPRODUCT CONTEXT:\n{big}\n\nTASK: Write one US eBay title optimized for Cassini."
    rules = (
        "You are an expert eBay SEO copywriter. Return ONLY the title text.\n\n"
        "Rules (US):\n"
        f"- <= {MAX_LEN} chars (shorter OK; no filler). Front-load strong buyer keywords.\n"
        "- <= 2 pipes ' | ' total. No emojis/ALL CAPS. Use inches as 'in'. Format 'W x H (x D)'.\n"
        "- Respect the product. DO NOT introduce unrelated category terms (e.g., laptop for kitchen item).\n"
        "- Keep brand if present and useful. Natural, non-stuffed phrasing.\n\n"
        "Output: only the final title.\n"
    )
    return rules + "\n" + user

def _read_rows(path: str, enc: str) -> List[Dict[str,str]]:
    rows = []
    with open(path, "r", encoding=enc, newline="") as f:
        rdr = csv.DictReader(f)
        def get(d, *keys):
            for k in keys:
                if k in d and d[k]:
                    return d[k]
            return ""
        for r in rdr:
            rows.append({
                "asin": get(r, "ASIN","asin","Asin"),
                "title": get(r, "amazon_title","Title","title"),
                "desc": get(r, "amazon_description","Description","description","desc"),
                "bullets": get(r, "bullet_points","Bullet Points","bullets"),
            })
    return rows

def read_rows(path: str) -> List[Dict[str,str]]:
    last_err = None
    for enc in ("utf-8-sig","cp1252","latin-1"):
        try:
            rows = _read_rows(path, enc)

            # --- Drop empty/NaN rows and keep only valid ASIN + non-empty Title ---
            import re
            asin_re = re.compile(r"^[A-Z0-9]{10}$")

            good = []
            for r in rows:
                asin   = (r.get("asin") or "").strip()
                title  = (r.get("title") or "").strip()
                desc   = (r.get("desc") or "").strip()
                bullets= (r.get("bullets") or "").strip()

                # skip fully empty or NaN
                if not (asin or title or desc or bullets):
                    continue
                if asin.lower() in {"nan","none","null"} and not title:
                    continue

                # keep only valid ASIN + title
                if asin_re.fullmatch(asin) and title:
                    good.append({"asin": asin, "title": title, "desc": desc, "bullets": bullets})

            print(f"[INFO] Loaded CSV with {enc} encoding. Valid rows: {len(good)} (from {len(rows)})")
            return good
        except Exception as e:
            last_err = e
    print(f"[ERROR] Could not read CSV. Last error: {last_err}")
    raise last_err


def risky_leak(title_out: str, context: str) -> bool:
    t = (title_out or "").lower()
    ctx = (context or "").lower()
    for w in RISKY:
        if w in t and w not in ctx:
            return True
    return False

# ------------------ MULTI-KEY HANDLING ------------------

def read_keys(path: str):
    keys = []
    # 1) File: one key per line; allow comments
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or line.lower().startswith("//"):
                    continue
                token = line.split()[0]
                if token:
                    keys.append(token)
    # 2) Env var fallbacks
    env_single = os.environ.get("OPENAI_API_KEY", "").strip()
    if env_single:
        keys.append(env_single)
    env_multi = os.environ.get("OPENAI_API_KEYS", "").strip()
    if env_multi:
        for tok in [t.strip() for t in env_multi.split(",") if t.strip()]:
            keys.append(tok)
    # De-duplicate, keep order
    seen = set()
    uniq = []
    for k in keys:
        if k not in seen:
            uniq.append(k)
            seen.add(k)
    return uniq

OpenAI = None
_clients_cache = {}
_dead = set()
_curr_idx = 0

def _get_client(key: str):
    if key in _clients_cache:
        return _clients_cache[key]
    global OpenAI
    client = OpenAI(api_key=key)
    _clients_cache[key] = client
    return client

def _is_rate_limit(err_text: str) -> bool:
    t = err_text.lower()
    return ("rate limit" in t) or ("too many requests" in t) or ("429" in t)

def _is_invalid_key(err_text: str) -> bool:
    t = err_text.lower()
    return ("incorrect api key" in t) or ("invalid_api_key" in t) or ("401" in t)

def call_openai_with_key(client, prompt: str) -> str:
    # Try Responses API first, then Chat Completions
    try:
        resp = client.responses.create(model=MODEL, input=prompt)
        text = getattr(resp, "output_text", None)
        if text:
            return text.strip()
    except Exception:
        pass
    resp = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You write Cassini-optimized US eBay titles. Return ONLY the title."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.3,
        max_tokens=120,
    )
    return resp.choices[0].message.content.strip()

def call_openai_failover(keys: List[str], prompt: str) -> str:
    global _curr_idx
    if not keys:
        raise RuntimeError("No API keys available. Put them in openai_keys.txt or set OPENAI_API_KEY(S).")
    attempts = 0
    max_attempts = max(4, 2 * len(keys))  # allow at least 2 full rotations
    while attempts < max_attempts:
        # pick next non-dead key
        tried_cycle = 0
        while keys[_curr_idx] in _dead and tried_cycle < len(keys):
            _curr_idx = (_curr_idx + 1) % len(keys)
            tried_cycle += 1
        key = keys[_curr_idx]
        try:
            client = _get_client(key)
            return call_openai_with_key(client, prompt)
        except Exception as e:
            msg = str(e)
            # Decide whether to rotate or retry same key
            rotate = False
            if SWITCH_ON_INVALID_KEY and _is_invalid_key(msg):
                _dead.add(key)
                rotate = True
                print(f"[WARN] Key {_curr_idx+1}/{len(keys)} appears invalid. Rotating...")
            elif SWITCH_ON_RATE_LIMIT and _is_rate_limit(msg):
                rotate = True
                print(f"[WARN] Rate limit on key {_curr_idx+1}/{len(keys)}. Rotating...")
            else:
                # Transient errors: brief backoff then retry same key once
                time.sleep(1.0 + 0.2 * attempts)
            if rotate:
                _curr_idx = (_curr_idx + 1) % len(keys)
                time.sleep(0.8 + 0.2 * attempts)  # small backoff before next key
        attempts += 1
    raise RuntimeError("All API keys failed after multiple attempts. Check limits/keys and try again.")

# ------------------ MAIN ------------------

def main():
    # Import OpenAI once so helper can instantiate clients
    try:
        global OpenAI
        from openai import OpenAI as _OpenAI
        OpenAI = _OpenAI
    except Exception as e:
        print(";ERROR__module 'openai' import failed. Install with: pip install --upgrade openai")
        raise e

    keys = read_keys(KEY_FILE)
    if not keys:
        print(f"[ERROR] No API keys found. Put them in {KEY_FILE} (one per line) or set OPENAI_API_KEY(S).")
        sys.exit(1)
    print(f"[INFO] Loaded {len(keys)} API key(s). Using failover rotation on errors.")

    rows = read_rows(INPUT_FILE)
    random.shuffle(rows)

    out_f = open(OUTPUT_FILE, "w", encoding="utf-8")
    log_f = open(LOG_FILE, "w", encoding="utf-8")

    print(f"✅ Starting US titles: {len(rows)} rows -> {OUTPUT_FILE}")
    for i, r in enumerate(rows, 1):
        _sleep_rate()
        context = " ".join(x for x in [r.get('title',''), r.get('desc',''), r.get('bullets','')] if x)
        prompt = _prompt(r["asin"], r["title"], r["desc"], r["bullets"])
        try:
            cand = call_openai_failover(keys, prompt)
            if risky_leak(cand, context):
                retry_prompt = prompt + "\n\nIMPORTANT: Your last title introduced unrelated tech/electronics words. Remove any unrelated category terms and strictly describe the product in the context above."
                cand2 = call_openai_failover(keys, retry_prompt)
                interim = context if risky_leak(cand2, context) else cand2
            else:
                interim = cand

            # Clean and enforce hard caps
            final = clean_title(interim, is_uk=False, max_len=MAX_LEN)
            if len(final) > MAX_LEN:
                final = smart_trim(final, max_len=MAX_LEN)
                final = strip_trailing_seps(final)
            # Ensure <= 2 pipes
            if final.count("|") > 2:
                parts = [p.strip(" -–—|/") for p in final.split("|")]
                final = " | ".join(parts[:3])
            final = strip_trailing_seps(final)
            if len(final) > MAX_LEN:
                final = final[:MAX_LEN].rstrip(" -–—|/")

            line = f"{r['asin']};{final}"
            out_f.write(line + "\n")
            log_f.write(f"[{i}] {r['asin']} -> {final}\n")
            print(f"✅ [{i}] {r['asin']} -> {final}")
        except Exception as e:
            err = f"⚠️ [{i}] {r['asin']} -> ERROR {e}"
            log_f.write(err + "\n")
            print(err)

    out_f.close()
    log_f.close()
    print(f"🏁 Done. Output: {OUTPUT_FILE} | Log: {LOG_FILE}")

if __name__ == "__main__":
    main()
