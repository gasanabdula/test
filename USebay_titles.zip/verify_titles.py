# verify_titles.py — stricter checks for eBay title hygiene
import sys, re

MAX_LEN = 80

def check_line(i, line: str):
    line = line.rstrip("\n")
    if ";" not in line:
        print(f"[{i}] ❌ Missing ';' separator: {line}")
        return
    asin, title = line.split(";", 1)
    ok = True
    issues = []

    if len(title) > MAX_LEN:
        issues.append(f">{MAX_LEN} chars ({len(title)})")
        ok = False
    if title.count("|") > 2:
        issues.append(f">2 pipes ({title.count('|')})")
        ok = False
    if re.search(r"[|/·•>→\-–—]\s*$", title):
        issues.append("trailing separator")
        ok = False
    if re.search(r"\binx\b", title, flags=re.I):
        issues.append("has 'inx' glitch")
        ok = False
    if re.search(r"\d+in\b", title, flags=re.I):
        issues.append("missing space before 'in' (e.g., 64in)")
        ok = False
    if re.search(r"\bin[WHLD]\b", title):
        issues.append("missing space after 'in' axis (inW/inH)")
        ok = False
    if re.search(r"\s*[xX×]\s*$", title):
        issues.append("dangling 'x' at end")
        ok = False

    if ok:
        print(f"[{i}] ✅ OK")
    else:
        print(f"[{i}] ❌ {asin} -> {title}")
        print("     " + "; ".join(issues))

def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "yaballe_titles.txt"
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            check_line(i, line)

if __name__ == "__main__":
    main()
