# clean_titles.py — one-off fixer for an existing yaballe_titles.txt using utils.clean_title
import sys
from utils import clean_title, strip_trailing_seps, smart_trim

MAX_LEN = 80

def main():
    in_path = "yaballe_titles.txt"
    out_path = "yaballe_titles_fixed.txt"
    if len(sys.argv) >= 2:
        in_path = sys.argv[1]
    if len(sys.argv) >= 3:
        out_path = sys.argv[2]

    with open(in_path, "r", encoding="utf-8") as f:
        lines = [ln.rstrip("\n") for ln in f]

    out_lines = []
    for ln in lines:
        if ";" not in ln:
            out_lines.append(ln)
            continue
        asin, title = ln.split(";", 1)
        fixed = clean_title(title, is_uk=False, max_len=MAX_LEN)
        if len(fixed) > MAX_LEN:
            fixed = smart_trim(fixed, MAX_LEN)
            fixed = strip_trailing_seps(fixed)
        if fixed.count("|") > 2:
            parts = [p.strip(" -–—|/") for p in fixed.split("|")]
            fixed = " | ".join(parts[:3])
        fixed = strip_trailing_seps(fixed)
        if len(fixed) > MAX_LEN:
            fixed = fixed[:MAX_LEN].rstrip(" -–—|/")
        out_lines.append(f"{asin};{fixed}")

    with open(out_path, "w", encoding="utf-8", newline="") as f:
        f.write("\n".join(out_lines))

    print(f"Saved cleaned file -> {out_path}")

if __name__ == "__main__":
    main()
