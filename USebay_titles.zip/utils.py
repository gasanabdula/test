# utils.py — robust cleaners for Cassini-friendly eBay titles (US)
import re, unicodedata

# ===== Restricted terms (your list retained) =====
RESTRICTED = set(x.strip().lower() for x in
    "Rings,Ring,giftcard,dress,jeans,thirt,t-shirt,socks,sock,pant,pants,"
    "Sandal,Costume,Blazer,Jacket,V-Neck,shoes,Jumpsuits,Shorts,Tights,Vest,"
    "Jean,Clothes,Hoodies,Slip,Slips,Bathcoat,bags,crossbody,handbag,"
    "Underwear,Boxer,boot,boots,Hoodie,Pullover,Footwear,Sneakers,knife,blade,"
    "razor,tote bag,tote".split(","))

# ===== Banned brands/words =====
BANNED_BRANDS = [
    r"\bamazon\s*basics\b",   # "Amazon Basics" with optional space
    r"\bamazonbasics\b",      # "AmazonBasics" joined
    r"\bamazon\b",            # "Amazon"
]

# IMPORTANT: '-' is NOT a separator to avoid breaking hyphenated words
SEP_CHARS = r"[|/·•>→–—]+"

def strip_emoji(text: str) -> str:
    return "".join(ch for ch in text if not (0x1F300 <= ord(ch) <= 0x1FAFF or 0x2600 <= ord(ch) <= 0x27BF))

def normalise_spaces(s: str) -> str:
    s = unicodedata.normalize("NFKC", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def fix_mojibake(s: str) -> str:
    table = {
        "вЂў": "•","вЂ“": "–","вЂ”": "—","вЂ˜": "'","вЂ’": "-","вЂ™": "'","вЂњ": '"',"вЂќ": '"',
        "â€“": "–","â€”": "—","â€˜": "'","â€™": "'","â€œ": '"',"â€\x9d": '"',"â€¢": "•",
    }
    for k,v in table.items():
        s = s.replace(k, v)
    return s

def collapse_separators(s: str) -> str:
    s = re.sub(r"\s*(?:%s)\s*" % SEP_CHARS, " | ", s)
    s = re.sub(r"(?:\s*\|\s*){3,}", " | ", s)  # collapse 3+ pipes
    return s

def limit_pipes(s: str, max_pipes: int = 2) -> str:
    parts = [p.strip(" –—|/") for p in re.split(r"\|", s)]
    out = " | ".join(parts[: max_pipes + 1]) if len(parts) > max_pipes else " | ".join(parts)
    return out

def fix_common_fraction_pipes(s: str) -> str:
    # Replace common piped fractions with slashes
    s = re.sub(r"\b1\s*\|\s*2\b", "1/2", s)
    s = re.sub(r"\b1\s*\|\s*4\b", "1/4", s)
    s = re.sub(r"\b3\s*\|\s*4\b", "3/4", s)
    return s

def fix_inch_and_dims(s: str) -> str:
    # Convert quotes to ' in' after a digit
    s = re.sub(r'(?<=\d)\s*(?:["”])', " in", s)
    # Convert 'inch'/'inches' to ' in'
    s = re.sub(r"\b(\d+(?:\.\d+)?)\s*(?:inches|inch)\b", r"\1 in", s, flags=re.IGNORECASE)
    # Fix 64in -> 64 in
    s = re.sub(r"\b(\d+(?:\.\d+)?)\s*in\b", r"\1 in", s, flags=re.IGNORECASE)
    # inW/inH/inD/inL -> in W/H/D/L
    s = re.sub(r"\bin([WHLD])\b", r"in \1", s)
    # 26 inx22 inx8 in -> 26 in x 22 in x 8 in
    s = re.sub(r"(\d(?:\.\d+)?)\s*in\s*x\s*(\d)", r"\1 in x \2", s, flags=re.IGNORECASE)
    s = re.sub(r"(\d(?:\.\d+)?)\s*inx\s*(\d)", r"\1 in x \2", s, flags=re.IGNORECASE)
    # Normalize X spacing: a x b (x c)
    s = re.sub(r"\b(\d+(?:\.\d+)?)\s*[xX×]\s*(\d+(?:\.\d+)?)\b", r"\1 x \2", s)
    s = re.sub(r"\b(\d+(?:\.\d+)?)\s*[xX×]\s*(\d+(?:\.\d+)?)\s*[xX×]\s*(\d+(?:\.\d+)?)\b", r"\1 x \2 x \3", s)
    return s

def strip_trailing_seps(s: str) -> str:
    s = re.sub(r"\s*(?:%s)\s*$" % SEP_CHARS, "", s).strip()
    # remove dangling 'x' or axis at end or 'with N'
    s = re.sub(r"\s*[xX×]\s*$", "", s)
    s = re.sub(r"\s*(?:W|H|D|L)\s*$", "", s)
    s = re.sub(r"\swith\s\d+$", "", s, flags=re.IGNORECASE)
    return s.strip()

def remove_restricted(s: str) -> str:
    pattern = r"\b(" + "|".join(re.escape(w) for w in sorted(RESTRICTED, key=len, reverse=True)) + r")\b"
    s = re.sub(pattern, "", s, flags=re.IGNORECASE)
    s = re.sub(r"\s{2,}", " ", s)
    return s.strip()

def remove_banned_brands(s: str) -> str:
    for pat in BANNED_BRANDS:
        s = re.sub(pat, "", s, flags=re.IGNORECASE)
    s = re.sub(r"\s{2,}", " ", s).strip()
    return s

def smart_trim(s: str, max_len: int = 80) -> str:
    s = s.strip()
    if len(s) <= max_len:
        return s
    cut = s[:max_len]
    # Prefer trimming at separators near the end
    m = re.search(r"[|,;/–—]\s*\S*$", cut[-12:])
    if m:
        idx = max_len - 12 + m.start()
        cut = cut[:idx]
    else:
        last_space = cut.rfind(" ")
        if last_space > 40:
            cut = cut[:last_space]
        else:
            cut = cut[:max_len]
    cut = strip_trailing_seps(cut)
    return cut

def clean_title(s: str, is_uk: bool = False, max_len: int = 80) -> str:
    s = fix_mojibake(s)
    s = s.replace("•", "|").replace("·", "|").replace("–", "-").replace("—", "-")
    s = strip_emoji(s)
    s = normalise_spaces(s)
    s = fix_common_fraction_pipes(s)     # NEW: fix '1 | 2' -> '1/2' etc.
    s = fix_inch_and_dims(s)
    s = collapse_separators(s)
    s = remove_banned_brands(s)          # NEW: drop Amazon/Amazon Basics
    if is_uk:
        s = re.sub(r"\bcolor\b", "colour", s, flags=re.IGNORECASE)
        s = re.sub(r"\bcenter\b", "centre", s, flags=re.IGNORECASE)
        s = re.sub(r"\borganizer\b", "organiser", s, flags=re.IGNORECASE)
        s = re.sub(r"\bliter(s?)\b", r"L\1", s, flags=re.IGNORECASE)
    s = limit_pipes(s, 2)
    s = strip_trailing_seps(s)
    s = remove_restricted(s)
    s = smart_trim(s, max_len=max_len)
    s = strip_trailing_seps(s)
    # Final belts and suspenders
    if s.count("|") > 2:
        parts = [p.strip(" -–—|/") for p in s.split("|")]
        s = " | ".join(parts[:3])
    if len(s) > max_len:
        s = smart_trim(s, max_len=max_len)
        s = strip_trailing_seps(s)
        if len(s) > max_len:
            s = s[:max_len].rstrip(" -–—|/")
    return s
